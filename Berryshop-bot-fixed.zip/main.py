import os
import json
import sqlite3
import asyncio
from aiohttp import web
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command

# Load env from system (Render provides env vars in settings)
TOKEN = os.getenv("TOKEN")
RENDER_EXTERNAL_URL = os.getenv("RENDER_EXTERNAL_URL", "")
PORT = int(os.getenv("PORT", "10000"))

if not TOKEN:
    raise RuntimeError("TOKEN env var is required")

bot = Bot(token=TOKEN, parse_mode="HTML")
dp = Dispatcher()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, "web")
DB_FILE = os.path.join(BASE_DIR, "shop.db")
DATA_JSON = os.path.join(WEB_DIR, "data.json")

# Ensure web dir exists
os.makedirs(WEB_DIR, exist_ok=True)

def get_products():
    # Read products table (adjust columns to your DB)
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    try:
        cur.execute("SELECT id, name, category, price, description, image FROM products ORDER BY id")
        rows = cur.fetchall()
    finally:
        conn.close()
    res = []
    for r in rows:
        pid, name, category, price, description, image = r
        res.append({
            "id": pid,
            "name": name or "",
            "category": category or "",
            "price": int(price or 0),
            "description": description or "",
            "image": f"images/{image}" if image else ""
        })
    return res

def refresh_web_data():
    data = get_products()
    with open(DATA_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

@dp.message(Command("start"))
async def cmd_start(msg: types.Message):
    web_url = RENDER_EXTERNAL_URL.rstrip("/") + "/web" if RENDER_EXTERNAL_URL else "/web"
    kb = types.ReplyKeyboardMarkup(
        keyboard=[[types.KeyboardButton(text="🛍 Открыть магазин", web_app=types.WebAppInfo(url=web_url))]],
        resize_keyboard=True
    )
    await msg.answer("Добро пожаловать! Открой магазин:", reply_markup=kb)

@dp.message(Command("admin"))
async def cmd_admin(msg: types.Message):
    # simple admin command to refresh data.json from DB
    admin_ids = os.getenv("ADMIN_IDS", "")
    allowed = [int(x) for x in admin_ids.split(",") if x.strip().isdigit()]
    if msg.from_user.id not in allowed:
        await msg.reply("Доступ запрещён.")
        return
    refresh_web_data()
    await msg.reply("Данные выгружены в web/data.json")

# Web handlers
async def index(request):
    return web.FileResponse(os.path.join(WEB_DIR, "index.html"))

async def static_handler(request):
    path = request.match_info.get("path")
    full = os.path.join(WEB_DIR, path)
    if os.path.isfile(full):
        return web.FileResponse(full)
    return web.Response(status=404, text="Not found")

async def api_products(request):
    # refresh before serving to keep in sync
    refresh_web_data()
    if os.path.exists(DATA_JSON):
        return web.FileResponse(DATA_JSON)
    return web.json_response([], status=200)

# webhook handler: receive updates from Telegram and feed to dispatcher
async def telegram_webhook(request):
    data = await request.json()
    update = types.Update(**data)
    await dp.feed_update(bot, update)
    return web.Response(status=200)

def create_app():
    app = web.Application()
    app.router.add_post("/webhook", telegram_webhook)
    app.router.add_get("/", index)
    app.router.add_get("/web", index)
    app.router.add_get("/web/{path:.+}", static_handler)
    app.router.add_get("/api/products", api_products)
    return app

async def on_startup(app):
    # set webhook to Render URL
    if RENDER_EXTERNAL_URL:
        await bot.set_webhook(f"{RENDER_EXTERNAL_URL.rstrip('/')}/webhook")
    else:
        print("RENDER_EXTERNAL_URL not set; webhook not configured")

async def on_cleanup(app):
    try:
        await bot.delete_webhook()
    except Exception:
        pass
    await bot.session.close()

def main():
    app = create_app()
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    refresh_web_data()
    web.run_app(app, port=PORT)

if __name__ == "__main__":
    main()
